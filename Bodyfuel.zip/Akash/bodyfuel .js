// ========== SUPABASE CONFIGURATION ==========
const SUPABASE_URL = 'https://tcadiftyubckovwczybr.supabase.co';
const SUPABASE_KEY = 'sb_publishable_0BoGoH1c8eQKVDz-APTwcg_uv8c3diy';
const OPENROUTER_KEY = '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';

// Initialize Supabase
let supabaseClient = null;
if (typeof supabase !== 'undefined') {
    supabaseClient = supabase.createClient(SUPABASE_URL, SUPABASE_KEY);
}

// Global variables
let deviceId = localStorage.getItem('device_id');
if (!deviceId) {
    deviceId = 'user_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    localStorage.setItem('device_id', deviceId);
}

let currentScanType = null;
let currentCameraStream = null;
let currentAnalysisResult = null;

// ========== Helper Functions ==========
function showToast(message) {
    let toast = document.createElement('div');
    toast.className = 'toast';
    toast.innerText = message;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 2500);
}

async function saveToLocalStorage(type, data) {
    let scans = JSON.parse(localStorage.getItem(`${type}_scans`) || '[]');
    scans.unshift({ ...data, id: Date.now(), timestamp: new Date().toISOString() });
    scans = scans.slice(0, 50);
    localStorage.setItem(`${type}_scans`, JSON.stringify(scans));
    loadRecentScans();
    loadStats();
}

function getFromLocalStorage(type) {
    return JSON.parse(localStorage.getItem(`${type}_scans`) || '[]');
}

// ========== Load Stats ==========
async function loadStats() {
    try {
        const bodyScans = getFromLocalStorage('body');
        const foodScans = getFromLocalStorage('food');
        
        const totalScans = bodyScans.length + foodScans.length;
        const totalCalories = foodScans.reduce((sum, item) => sum + (item.calories || 0), 0);
        
        document.getElementById('totalScans').innerText = totalScans;
        document.getElementById('totalCalories').innerText = totalCalories;
    } catch(e) {
        console.log('Stats error:', e);
    }
}

// ========== Load Recent Scans ==========
function loadRecentScans() {
    const bodyScans = getFromLocalStorage('body');
    const foodScans = getFromLocalStorage('food');
    
    let allScans = [
        ...bodyScans.map(s => ({ ...s, type: 'body' })),
        ...foodScans.map(s => ({ ...s, type: 'food' }))
    ];
    allScans.sort((a, b) => b.timestamp.localeCompare(a.timestamp));
    allScans = allScans.slice(0, 5);
    
    const container = document.getElementById('recentList');
    if (!container) return;
    
    if (allScans.length === 0) {
        container.innerHTML = '<div style="text-align:center; color:#999; padding:20px;">No scans yet</div>';
        return;
    }
    
    container.innerHTML = allScans.map(scan => {
        if (scan.type === 'body') {
            return `
                <div class="recent-item recent-item-body">
                    <div class="recent-info">
                        <div class="recent-title">🧍 Posture Check</div>
                        <div class="recent-meta">Score: ${scan.posture_score}/100 • ${new Date(scan.timestamp).toLocaleDateString()}</div>
                    </div>
                    <button class="delete-btn" onclick="deleteScan('body', ${scan.id})">🗑️</button>
                </div>
            `;
        } else {
            return `
                <div class="recent-item recent-item-food">
                    <div class="recent-info">
                        <div class="recent-title">🍛 ${scan.food_name}</div>
                        <div class="recent-meta">${scan.calories} kcal • ${new Date(scan.timestamp).toLocaleDateString()}</div>
                    </div>
                    <button class="delete-btn" onclick="deleteScan('food', ${scan.id})">🗑️</button>
                </div>
            `;
        }
    }).join('');
}

function deleteScan(type, id) {
    let scans = getFromLocalStorage(type);
    scans = scans.filter(s => s.id !== id);
    localStorage.setItem(`${type}_scans`, JSON.stringify(scans));
    loadRecentScans();
    loadStats();
    showToast('Deleted');
}

// ========== Scanner Functions ==========
function openScanner(type) {
    currentScanType = type;
    const modal = document.getElementById('scannerModal');
    const title = document.getElementById('modalTitle');
    title.innerText = type === 'body' ? '🧍 Body Posture Scan' : '🍛 Food Nutrition Scan';
    modal.style.display = 'flex';
}

function closeScanner() {
    document.getElementById('scannerModal').style.display = 'none';
    document.getElementById('analysisResult').style.display = 'none';
    document.getElementById('analysisResult').innerHTML = '';
    currentAnalysisResult = null;
}

// ========== Camera Functions ==========
async function openCamera() {
    const cameraModal = document.getElementById('cameraModal');
    const video = document.getElementById('cameraVideo');
    
    try {
        if (currentCameraStream) {
            currentCameraStream.getTracks().forEach(track => track.stop());
        }
        currentCameraStream = await navigator.mediaDevices.getUserMedia({
            video: { facingMode: 'environment' }
        });
        video.srcObject = currentCameraStream;
        cameraModal.style.display = 'flex';
    } catch(e) {
        showToast('Camera access denied. Please allow permission.');
    }
}

function closeCameraModal() {
    if (currentCameraStream) {
        currentCameraStream.getTracks().forEach(track => track.stop());
        currentCameraStream = null;
    }
    document.getElementById('cameraModal').style.display = 'none';
}

function capturePhoto() {
    const video = document.getElementById('cameraVideo');
    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    canvas.getContext('2d').drawImage(video, 0, 0);
    
    canvas.toBlob(async (blob) => {
        const file = new File([blob], 'photo.jpg', { type: 'image/jpeg' });
        await analyzeImage(file);
        closeCameraModal();
    }, 'image/jpeg');
}

// ========== AI Analysis ==========
async function analyzeImage(file) {
    const reader = new FileReader();
    const resultDiv = document.getElementById('analysisResult');
    
    reader.onloadend = async function() {
        resultDiv.style.display = 'block';
        resultDiv.innerHTML = '<div style="text-align:center">🤖 AI analyzing...<br><div class="spinner"></div></div>';
        
        try {
            let prompt = '';
            if (currentScanType === 'body') {
                prompt = `You are a posture expert. Analyze this body posture photo. Return ONLY valid JSON (no other text):
                {
                    "posture_score": number between 0-100,
                    "issues": ["issue1", "issue2"],
                    "advice": "health tip in Hindi"
                }`;
            } else {
                prompt = `You are a nutrition expert. Analyze this food photo. Return ONLY valid JSON (no other text):
                {
                    "food_name": "name of the dish",
                    "calories": number,
                    "protein_g": number,
                    "carbs_g": number,
                    "fat_g": number,
                    "health_tip": "advice in Hindi"
                }`;
            }
            
            const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${OPENROUTER_KEY}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    model: 'google/gemini-2.0-flash-exp:free',
                    messages: [{
                        role: 'user',
                        content: [
                            { type: 'text', text: prompt },
                            { type: 'image_url', image_url: reader.result }
                        ]
                    }]
                })
            });
            
            const data = await response.json();
            let content = data.choices[0].message.content;
            const jsonMatch = content.match(/\{[\s\S]*\}/);
            const result = JSON.parse(jsonMatch[0]);
            currentAnalysisResult = result;
            
            if (currentScanType === 'body') {
                resultDiv.innerHTML = `
                    <h4>✅ Analysis Complete</h4>
                    <p><strong>Posture Score:</strong> ${result.posture_score}/100</p>
                    <p><strong>Issues:</strong> ${result.issues?.join(', ') || 'Good posture!'}</p>
                    <p><strong>💡 Advice:</strong> ${result.advice || 'Keep your back straight!'}</p>
                    <button class="save-result-btn" onclick="saveAnalysisResult()">💾 Save to History</button>
                `;
            } else {
                resultDiv.innerHTML = `
                    <h4>🍽️ ${result.food_name}</h4>
                    <p><strong>Calories:</strong> ${result.calories} kcal</p>
                    <p><strong>Protein:</strong> ${result.protein_g}g | <strong>Carbs:</strong> ${result.carbs_g}g | <strong>Fat:</strong> ${result.fat_g}g</p>
                    <p><strong>💡 Tip:</strong> ${result.health_tip || 'Balanced diet rakhein!'}</p>
                    <button class="save-result-btn" onclick="saveAnalysisResult()">💾 Save to History</button>
                `;
            }
        } catch(e) {
            resultDiv.innerHTML = `<p style="color:red;">Error: ${e.message}<br>Please try again.</p>`;
        }
    };
    reader.readAsDataURL(file);
}

// Handle file upload
document.getElementById('fileInput')?.addEventListener('change', function(e) {
    if (e.target.files && e.target.files[0]) {
        analyzeImage(e.target.files[0]);
    }
});

// ========== Save Result ==========
function saveAnalysisResult() {
    if (!currentAnalysisResult) return;
    
    if (currentScanType === 'body') {
        saveToLocalStorage('body', {
            posture_score: currentAnalysisResult.posture_score,
            issues: currentAnalysisResult.issues,
            advice: currentAnalysisResult.advice
        });
    } else {
        saveToLocalStorage('food', {
            food_name: currentAnalysisResult.food_name,
            calories: currentAnalysisResult.calories,
            protein: currentAnalysisResult.protein_g,
            carbs: currentAnalysisResult.carbs_g,
            fat: currentAnalysisResult.fat_g
        });
    }
    
    showToast('Saved successfully! ✅');
    closeScanner();
}

// ========== Clear All Data ==========
function clearAllData() {
    if (confirm('Delete all your health data? This cannot be undone.')) {
        localStorage.removeItem('body_scans');
        localStorage.removeItem('food_scans');
        loadRecentScans();
        loadStats();
        showToast('All data cleared');
    }
}

// ========== Expose Functions to Global ==========
window.openScanner = openScanner;
window.closeScanner = closeScanner;
window.openCamera = openCamera;
window.closeCameraModal = closeCameraModal;
window.capturePhoto = capturePhoto;
window.saveAnalysisResult = saveAnalysisResult;
window.deleteScan = deleteScan;
window.clearAllData = clearAllData;

// ========== Initialize ==========
loadStats();
loadRecentScans();

console.log('App ready!');